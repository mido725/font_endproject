const paymentMessages = {
    'Direct bank transfer': 'Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order will not be shipped until the funds have cleared in our account.',
    'Check payments': 'Please send a check to Store Name, Store Street, Store Town, Store State / County, Store Postcode.',
    'Cash on delivery': 'Pay with cash upon delivery.',
    'PayPal': 'Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.'
  };
  
  const radios = document.querySelectorAll('input[type="radio"]');
  const messageDiv = document.getElementById('message');
  
  radios.forEach(radio => {
    radio.addEventListener('change', function() {
      if (this.checked) {
        messageDiv.style.display = 'block';
        messageDiv.textContent = paymentMessages[this.value];
      }
    });
  });
  