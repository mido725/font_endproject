function updateCartButtonState() {
    var quantityInput = document.getElementById('quantityInput');
    var updateCartButton = document.getElementById('updateCartButton');

    // Enable the "UPDATE CART" button only if the quantity is greater than 0
    updateCartButton.disabled = quantityInput.value <= 0;
}

function updateCart() {
    // Implement your update cart logic here
    alert('Updating cart!');
}