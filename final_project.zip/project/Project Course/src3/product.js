export const productsData = [
    {
        id: 1,
        title: "Anchor Bracelet",
        gender: "Accessories",
        price: '150.00-180.00',
        image: 'image/ACCE/product-accessory2.jpg'
    },
    {
        id: 2,
        title: "Black Over-the-shoulder Handbag",
        gender: "Accessories",
        price: '150.00',
        image: 'image/ACCE/product-bag2-400x400.jpg'
    },
    {
        id: 3,
        title: "Boho Bangle Bracelet",
        gender: "Accessories",
        price: '150.00-170.00',
        image: 'image/ACCE/product-accessory1-400x400.jpg'
    },
    {
        id: 4,
        title: "Bright Gold Purse With Chain",
        gender: "Accessories",
        price: '150.00',
        image: 'image/ACCE/product-bag4-400x400.jpg'
    },
    {
        id: 5,
        title: "Bright Red Bag",
        gender: "Accessories",
        price: '100.00-140.00',
        image: 'image/ACCE/product-bag3-400x400.jpg'
    },
    {
        id: 6,
        title: "Dark Gray Jeans",
        gender: "Accessories",
        price: '150',
        image: 'image/ACCE/product-accessory3-400x400.jpg'
    },
    {
        id: 7,
        title: "Light Brown Purse",
        gender: "Accessories",
        price: '150.00',
        image: 'image/ACCE/product-bag1-400x400.jpg'
    }
   
];
