export const productsData = [
    {
        id: 13,
        title: "Dark Blue Denim Jeans",
        gender: "Men",
        price: '150.00',
        image: './image/Everthing/product-m-jeans2-400x400.jpg'
    },
    {
        id: 14,
        title: "Dark Brown Jeans",
        gender: "Men",
        price: '150.00',
        image: './image/Everthing/product-m-jeans1-400x400.jpg'
    },
    {
        id: 15,
        title: "Dark Gray Jeans",
        gender: "Men",
        price: '150.00',
        image: './image/Everthing/product-m-jeans4-400x400.jpg'
    },
    {
        id: 16,
        title: "DNK Black Shoes",
        gender: "Women",
        price: '175.00 – 200.00',
        image: './image/Everthing/sports-shoe5-400x400.jpg'
    },
    {
        id: 17,
        title: "DNK Blue Shoes",
        gender: "Men",
        price: '200.00 – 240.00',
        image: './image/Everthing/sports-shoe1-400x400.jpg'
    },
    {
        id: 18,
        title: "DNK Green Shoes",
        gender: "Men",
        price: '250.00 – 290.00',
        image: './image/Everthing/sports-shoe4-400x400.jpg'
    },
    {
        id: 19,
        title: "DNK Green Tshirt",
        gender: "Men",
        price: '42.00',
        image: './image/Everthing/tshirt4-300x300.jpg'
    },
    {
        id: 20,
        title: "DNK Red Shoes",
        gender: "Men",
        price: '150.00',
        image: './image/Everthing/sports-shoe2-400x400.jpg'
    },
    {
        id: 21,
        title: "DNK Yellow Shoes",
        gender: "Men",
        price: '120.00',
        image: './image/Everthing/sports-shoe3-400x400.jpg'
    },
    {
        id: 22,
        title: "Faint Washed Denim Blue Jeans",
        gender: "Men",
        price: '150.00-170.00',
        image: './image/Everthing/product-m-jeans3-400x400.jpg'
    },
    {
        id: 23,
        title: "Flamingo Tshirt",
        gender: "Women",
        price: '25.00-28.00',
        image: './image/Everthing/tshirt3-400x400.jpg'
    },
    {
        id: 24,
        title: "Gray Pattern Tshirt",
        gender: "Women",
        price: '30.00-34.00',
        image: './image/Everthing/tshirt7-400x400.jpg'
    }
];
