import { productsData } from '../src0/product2.js';


const productsDOM = document.querySelector('.products');
const cartTotal = document.querySelector('.sub');
const cartTotal1 = document.querySelector('.subt');
const cartitemcounter = document.querySelector('.count');
const cartContent = document.querySelector('.listcart')

// const clearCart = document.querySelector('.clear-cart')
 const searchInput = document.querySelector('.search')
// console.log(cartTotal,cartitemcounter,cartContent)
let cart=[]
let buttonsdom=[]


class UI {
    // ====== Display Products on DOM ======
    displayProducts(products) {
        let result = '';
        products.forEach(item => {
            result += `
            <div class="product">
                <div class="product-image">
                    <a href="../profile_product/1.html"  data-id='${item.id}'><img src="${item.image}" alt=""></a>
                    <div class="bag-icon"><i class="fa-solid fa-bag-shopping bag-icon1"  data-id='${item.id}'></i></div>
                </div>
                <h3>${item.title}</h3>
                <h6>${item.gender}</h6>
                <p>${item.price}</p>
                <div class="stars">
                    <i class="fa-regular fa-star" ></i>
                    <i class="fa-regular fa-star"></i>
                    <i class="fa-regular fa-star"></i>
                    <i class="fa-regular fa-star"></i>
                    <i class="fa-regular fa-star"></i>
                </div>
            </div>`;
        });
        productsDOM.innerHTML = result;
    }
    getCartBtns() {
        const addCartBtns = document.querySelectorAll('.bag-icon1');
        addCartBtns.forEach((btn) => {
          btn.addEventListener('click', (e) => {
            const id = e.target.dataset.id;
            const addedProduct = { ...Storage.getProducts(id) };
      
            // Check if the item already exists in the cart
            const exists = cart.some((item) => item.id === addedProduct.id);
            if (!exists) {
              cart = [...cart, addedProduct];
              Storage.saveCart(cart);
      
              this.setCartValue(cart);
              this.addCartItem(cart);
            } 
          });
        });
      }

      searchItem() {
        searchInput.addEventListener('input', (e) => {
          const searchValue = e.target.value.toLowerCase()
          // console.log(searchValue);
          const filteredProducts = productsData.filter((product) => {
            return product.title.toLowerCase().includes(searchValue)
          })
          this.displayProducts(filteredProducts)
        })
      }
      
      
      addCartItem(cartItem) {
        let result = '';
        cartItem.forEach(item => {
          result += `
            <div class="item">
              <div class="item-cart">
                <img src="${item.image}" alt="">
                <div class="editcaption">
                  <h3>${item.title}</h3>
                  <p>1 x${item.price}</p>
                </div>
                <div class="delete">
                  <i class="fa-solid fa-xmark trash" data-id="${item.id}"></i>
                </div>
              </div>
            </div>
          `;
        });
        cartContent.innerHTML = result;
        cartitemcounter.textContent = cartItem.length;
      }


      setCartValue(cart) {
        const totalPrice = cart.reduce((total, curr) => {
          return total + parseFloat(curr.price); // Ensure curr.price is parsed as a float/number
        }, 0);
      
        cartTotal.textContent = `Total Price : $${totalPrice.toFixed(2)}`; // Format total price as currency
        cartTotal1.textContent = `${totalPrice.toFixed(2)}`; // Format total price as currency
      }
      
      setUpApp() {
        // get cart from local storage  - update global cart
        cart = Storage.getCart() || []
        this.addCartItem(cart)
        this.setCartValue(cart)
        cart.forEach((item) => {
          let addedCart = document.querySelector(`[data-id="${item.id}"]`)
          addedCart.disabled = true
        })
    
    
      }
      removeItem(id) {
        // update cart global variable
        cart = cart.filter((item) => {
             return  item.id !== id
        })
        Storage.saveCart(cart)
        this.setCartValue(cart)
        // ======================== test ===========================
        // cart.forEach((item)=>{
        //   let addedCart=  !document.querySelector(`[data-id="${item.id}"]`)
    
        //       addedCart.textContent = "Buy"
        //       addedCart.disabled = false
    
        // })
      }
      cartLogic() {
        cartContent.addEventListener('click', (e) => {
          // =================================== functions ==================================         
          const removeItemFromTheCart = (target) => {
            const removedItem = cart.find((item) => {
              return item.id == parseInt(target.dataset.id)
            })
            this.removeItem( removedItem.id)
            this.setCartValue(cart)
            Storage.saveCart(cart)
            this.addCartItem(cart)
          }
          // =============================== calling function =====================================
          // console.log(e.target);
          if (e.target.classList.contains('trash')) {
            // console.log('trash');
            removeItemFromTheCart(e.target)
          }
    
    
        })
      }
}

class Storage {
    static saveProducts(products) {
        localStorage.setItem('products', JSON.stringify(products));
    }

    static getProducts(id) {
        const _products = JSON.parse(localStorage.getItem('products'));
        return _products.find(p => p.id === parseInt(id));
    }
    static saveCart(cart) {
        localStorage.setItem('cart', JSON.stringify(cart))
      }
      static getCart() {
        return JSON.parse(localStorage.getItem('cart'))
      }
}



document.addEventListener('DOMContentLoaded', () => {
    const ui = new UI();
    ui.displayProducts(productsData);
    ui.getCartBtns();
    ui.setUpApp();
    ui.cartLogic();
    ui.searchItem()

    // store our products in local storage
    Storage.saveProducts(productsData);
});


// ===========================================================
let iconcart = document.querySelectorAll('.icon-cart');
let body = document.querySelector('body');
let closecart=document.querySelector('.close');


iconcart[0].addEventListener('click', () => {
    body.classList.toggle('showcart');
});
closecart.addEventListener('click', () => {
    body.classList.toggle('showcart');
});
