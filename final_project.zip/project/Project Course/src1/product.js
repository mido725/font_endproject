export const productsData = [
    {
        id: 1,
        title: "Anchor Bracelet",
        gender: "Accessories",
        price: '150.00 – 180.00',
        image: 'image/Everthing/product-accessory2-400x400.jpg'
    },
    {
        id: 2,
        title: "Basic Gray Jeans",
        gender: "Women",
        price: '150.00',
        image: 'image/Everthing/product-w-jeans4-400x400.jpg'
    },
    {
        id: 3,
        title: "Black Over-the-shoulder Handbag",
        gender: "Accessories",
        price: '150.00',
        image: 'image/Woman/product-bag2-400x400.jpg'
    },
    {
        id: 4,
        title: "Blue Denim Jeans",
        gender: "Women",
        price: '150.00',
        image: 'image/Everthing/product-w-jeans2-400x400.jpg'
    },
    {
        id: 5,
        title: "Blue Denim Shorts",
        gender: "Women",
        price: '130.00',
        image: 'image/Everthing/product-w-jeans1-400x400.jpg'
    },
    {
        id: 6,
        title: "Boho Bangle Bracelet",
        gender: "Accessories",
        price: '150.00-170',
        image: 'image/Woman/product-accessory1-400x400.jpg'
    },
    {
        id: 7,
        title: "Bright Gold Purse With Chain",
        gender: "Accessories",
        price: '150.00',
        image: 'image/Everthing/product-bag4-400x400.jpg'
    },
    {
        id: 8,
        title: "Boho Bangle Bracelet",
        gender: "Accessory",
        price: '100-140.00',
        image: 'image/Everthing/product-bag3-400x400.jpg'
    },
    {
        id: 9,
        title: "Buddha Bracelet",
        gender: "Accessory",
        price: '150.00',
        image: 'image/Everthing/product-accessory3-400x400.jpg'
    },
    {
        id: 10,
        title: "DNK Black Shoes",
        gender: "Woman",
        price: '175.00-200.00',
        image: 'image/Woman/sports-shoe5-400x400.jpg'
    },
    {
        id: 11,
        title: "Flamingo Tshirt",
        gender: "Woman",
        price: '25.00-28.00',
        image: 'image/Woman/tshirt3-400x400.jpg'
    },
    {
        id: 12,
        title: "Flamingo Tshirt",
        gender: "Woman",
        price: '30.00-34.00',
        image: 'image/Woman/tshirt7-400x400.jpg'
    }
];
