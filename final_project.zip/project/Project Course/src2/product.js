export const productsData = [
    {
        id: 1,
        title: "Black Hoodie",
        gender: "Men",
        price: '150.00',
        image: 'image/Men/product-hoodie1-400x400.jpg'
    },
    {
        id: 2,
        title: "Blue Hoodie",
        gender: "Men",
        price: '150.00',
        image: 'image/Men/product-hoodie2-400x400.jpg'
    },
    {
        id: 3,
        title: "Blue Tshirt",
        gender: "Men",
        price: '40.00',
        image: 'image/Men/tshirt2-300x300.jpg'
    },
    {
        id: 4,
        title: "Dark Blue Denim Jeans",
        gender: "Men",
        price: '150.00',
        image: 'image/Men/product-m-jeans2-400x400.jpg'
    },
    {
        id: 5,
        title: "Dark Brown Jeans",
        gender: "Men",
        price: '150.00',
        image: 'image/Men/product-m-jeans1-400x400.jpg'
    },
    {
        id: 6,
        title: "Dark Gray Jeans",
        gender: "Men",
        price: '120.00-$170',
        image: 'image/Men/product-m-jeans4-400x400.jpg'
    },
    {
        id: 7,
        title: "DNK Blue Shoes",
        gender: "Men",
        price: '200.00-240.00',
        image: 'image/Men/sports-shoe1-400x400.jpg'
    },
    {
        id: 8,
        title: "DNK Green Shoes",
        gender: "Accessory",
        price: '250-290.00',
        image: 'image/Men/sports-shoe4-400x400.jpg'
    },
    {
        id: 9,
        title: "DNK Green Tshirt",
        gender: "Men",
        price: '42.00',
        image: 'image/Men/tshirt4-300x300.jpg'
    },
    {
        id: 10,
        title: "DNK Red Shoes",
        gender: "Men",
        price: '150.00',
        image: 'image/Men/sports-shoe2-400x400.jpg'
    },
    {
        id: 11,
        title: "DNK Yellow Shoes",
        gender: "Men",
        price: '120.00',
        image: 'image/Men/sports-shoe3-400x400.jpg'
    },
    {
        id: 12,
        title: "Faint Washed Denim Blue Jeans",
        gender: "Men",
        price: '150.00',
        image: 'image/Men/product-m-jeans3-400x400.jpg'
    }
    
];
