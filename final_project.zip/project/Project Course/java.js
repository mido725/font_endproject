function updatePrice(value) {
    const display = document.getElementById('priceDisplay');
    const formattedValue = value == 290 ? `$${value}` : `\$${value}`;
    const price = `${formattedValue} — $290`; 
    display.textContent = `Price: ${price}`;
  }